extends Sprite2D

# --- 1. ZMIENNE ---
var speed = 400
var punkty = 0
var speed_wroga = 150
var czy_koniec = false
var ścieżka_zapisu = "user://ranking.save"
var lista_wynikow = [] # Przechowuje słowniki: {"name": "Imię", "score": 10}

# --- 2. START GRY ---
func _ready():
	wczytaj_wyniki()
	odswiez_tekst_tabeli()
	
	# Ukrywamy pole imienia na samym początku
	var pole = get_parent().get_node_or_null("Koniec/PoleImienia")
	if pole:
		pole.hide()

# --- 3. GŁÓWNA PĘTLA ---
func _process(delta):
	obsluga_pauzy()
	obsluga_restartu()
	
	if czy_koniec or get_tree().paused: 
		return

	# STEROWANIE
	var kierunek = Vector2.ZERO
	if Input.is_action_pressed("ui_right"): kierunek.x += 1
	if Input.is_action_pressed("ui_left"): kierunek.x -= 1
	if Input.is_action_pressed("ui_up"): kierunek.y -= 1
	if Input.is_action_pressed("ui_down"): kierunek.y += 1
	
	position += kierunek.normalized() * speed * delta
	
	# ŚCIANY
	position.x = clamp(position.x, 0, 1152)
	position.y = clamp(position.y, 0, 648)

	# PRZECIWNIK
	var wrog = get_parent().get_node_or_null("Przeciwnik")
	if wrog != null:
		if position.distance_to(wrog.position) < 50:
			koniec_gry()
		
		if not czy_koniec:
			var kierunek_do_gracza = (position - wrog.position).normalized()
			wrog.position += kierunek_do_gracza * speed_wroga * delta

	# SKARB
	var skarb = get_parent().get_node_or_null("Skarb")
	if skarb != null:
		if position.distance_to(skarb.position) < 50:
			punkty += 1
			var etykieta = get_parent().get_node_or_null("Licznik")
			if etykieta != null: etykieta.text = "Punkty: " + str(punkty)
			skarb.position = Vector2(randf_range(100, 1000), randf_range(100, 500))

# --- 4. SYSTEM RANKINGU I KOŃCA GRY ---

func koniec_gry():
	if czy_koniec: return
	czy_koniec = true
	speed = 0
	
	var napis = get_parent().get_node_or_null("Koniec")
	var pole = get_parent().get_node_or_null("Koniec/PoleImienia")
	
	if napis:
		napis.text = "KONIEC GRY! Wynik: " + str(punkty) + "\nWPISZ IMIĘ I NACIŚNIJ ENTER"
		napis.show()
	
	if pole:
		pole.show()
		pole.grab_focus() # Kursor automatycznie wskakuje do pola
		if not pole.text_submitted.is_connected(_on_imie_wpisane):
			pole.text_submitted.connect(_on_imie_wpisane)

func _on_imie_wpisane(nowe_imie):
	if nowe_imie == "": nowe_imie = "Anonim"
	
	aktualizuj_tabele(nowe_imie, punkty)
	
	var pole = get_parent().get_node_or_null("Koniec/PoleImienia")
	var napis = get_parent().get_node_or_null("Koniec")
	
	if pole: pole.hide()
	if napis:
		napis.text = "ZAPISANO! TWOJE TOP 3:\n" + generuj_top_3() + "\nNaciśnij R aby restartować"

func aktualizuj_tabele(imie, wynik):
	var nowy_wpis = {"name": imie, "score": wynik}
	lista_wynikow.append(nowy_wpis)
	
	# Sortowanie od największego wyniku
	lista_wynikow.sort_custom(func(a, b): return a["score"] > b["score"])
	
	# Zatrzymujemy tylko 10 najlepszych wyników w pamięci
	if lista_wynikow.size() > 10:
		lista_wynikow = lista_wynikow.slice(0, 10)
	zapisz_wyniki()

func generuj_top_3():
	var tekst = ""
	var limit = min(lista_wynikow.size(), 3)
	for i in range(limit):
		tekst += str(i+1) + ". " + lista_wynikow[i]["name"] + ": " + str(lista_wynikow[i]["score"]) + "\n"
	return tekst

func odswiez_tekst_tabeli():
	var etykieta = get_parent().get_node_or_null("MenuPauzy/Panel/ListaWynikow")
	if etykieta != null:
		var tekst = "--- RANKING TOP 5 ---\n"
		var limit = min(lista_wynikow.size(), 5)
		for i in range(limit):
			tekst += str(i+1) + ". " + lista_wynikow[i]["name"] + ": " + str(lista_wynikow[i]["score"]) + " pkt\n"
		etykieta.text = tekst

# --- 5. OBSŁUGA UI I PLIKÓW ---

func obsluga_pauzy():
	if Input.is_action_just_pressed("ui_cancel"):
		get_tree().paused = !get_tree().paused
		var menu = get_parent().get_node_or_null("MenuPauzy")
		if menu != null:
			if get_tree().paused: 
				odswiez_tekst_tabeli()
				menu.show()
			else: 
				menu.hide()

func obsluga_restartu():
	if czy_koniec or get_tree().paused:
		if Input.is_key_pressed(KEY_R):
			get_tree().paused = false
			get_tree().reload_current_scene()

func _on_graj_dalej_pressed():
	get_tree().paused = false
	var menu = get_parent().get_node_or_null("MenuPauzy")
	if menu != null: menu.hide()

func zapisz_wyniki():
	var plik = FileAccess.open(ścieżka_zapisu, FileAccess.WRITE)
	if plik:
		plik.store_line(JSON.stringify(lista_wynikow))
		plik.close()

func wczytaj_wyniki():
	if FileAccess.file_exists(ścieżka_zapisu):
		var plik = FileAccess.open(ścieżka_zapisu, FileAccess.READ)
		var dane = JSON.parse_string(plik.get_line())
		if dane != null:
			lista_wynikow = dane
		plik.close()
